TCG VAULT — Riot showcase site
================================

This folder is a static website. No build step is required.

HOW TO PREVIEW LOCALLY
----------------------
Double-click index.html. It opens in your browser.

HOW TO PUT IT ONLINE WITH GITHUB PAGES
--------------------------------------
1. Create a new public repository, for example: tcg-vault-showcase
2. Upload index.html and the assets folder.
3. Open repository Settings > Pages.
4. Under Build and deployment, select "Deploy from a branch".
5. Select the main branch and / (root), then Save.
6. GitHub will provide a public URL. Put that URL into Riot's Product URL field.

IMPORTANT
---------
- Keep the Riot disclaimer visible on the published page.
- The Riftbound section intentionally uses generic placeholders while API approval is pending.
- Do not add unofficial Riftbound card art/assets. Use authorized Riot API assets after approval.
- Never publish your Riot API key in this website, GitHub repository, JavaScript, screenshots, or source code.
